create
    definer = root@localhost procedure insert_person(IN p_in int)
begin 
	declare i int;
	declare name varchar(20);
	declare address varchar(100);
	set i = 1;
	while i <= p_in do
		set name = concat('name',i);
		set address = concat('#','address',i);
			insert into person(name,address) values(name,address);
			set i = i+1;
	end while;
end;

